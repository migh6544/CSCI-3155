package jsy.student

import jsy.lab1._
import scala.collection.View

object Lab1 extends jsy.util.JsyApplication with jsy.lab1.Lab1Like {
  import jsy.lab1.Parser
  import jsy.lab1.ast._

  /*
   * CSCI 3155: Lab 1
   * <Michael Ghattas>
   *
   * Partner: <Jisoo Park>
   * Collaborators: <None>
   */

  /*
   * Fill in the appropriate portions above by replacing things delimited
   * by '<'... '>'.
   *
   * Replace the '???' expression with your code in each function. The
   * '???' expression is a Scala expression that throws a NotImplementedError
   * exception.
   *
   * Do not make other modifications to this template, such as
   * - adding "extends App" or "extends Application" to your Lab object,
   * - adding a "main" method, and
   * - leaving any failing asserts.
   *
   * Your lab will not be graded if it does not compile.
   *
   * This template compiles without error. Before you submit comment out any
   * code that does not compile or causes a failing assert.  Simply put in a
   * '???' as needed to get something that compiles without error.
   */

  /*
   * Example: Test-driven development of plus
   *
   * A convenient, quick-and-dirty way to experiment, especially with small code
   * fragments, is to use the interactive Scala interpreter. The simplest way
   * to use the interactive Scala interpreter in IntelliJ is through a worksheet,
   * such as Lab1Worksheet.sc. A Scala Worksheet (e.g., Lab1Worksheet.sc) is code
   * evaluated in the context of the project with results for each expression
   * shown inline.
   *
   * Step 0: Sketch an implementation in Lab1.scala using ??? for unimmplemented things.
   * Step 1: Do some experimentation in Lab1Worksheet.sc.
   * Step 2: Write a test in Lab1Spec.scala, which should initially fail because of the ???.
   * Step 3: Fill in the ??? to finish the implementation to make your test pass.
   */

  def plus(x: Int, y: Int): Int = x + y //def plus(x: Int, y: Int): Int = ???


  /* Exercises */
  
  def abs(n: Double): Double = if (n < 0) -n else n // Converting negative values to positive values, and keeping postive values postive

  def xor(a: Boolean, b: Boolean): Boolean = if (a != b) true else false // Checking if a and b have the same value, if not, then true, else false

  def repeat(s: String, n: Int): String = {
    require(n >= 0) // Ensuring parameters are within range to exclude edge cases
    if (n == 0) {""} // If n=0 which means there is no reptition, so return empty string
    else {
      s +  repeat(s, n-1) // Repeat printing by adding "s" n-times as a string
    } 
  }

  def sqrtStep(c: Double, xn: Double): Double = (xn - (((xn * xn) - c) / (2 * xn))) // Converting the mathematical operation provided into a function

  def sqrtN(c: Double, x0: Double, n: Int): Double = {
    require(n >= 0) // Ensuring parameters are within range to exclude edge cases
    require(x0 >= 0) // Ensuring parameters are within range to exclude edge cases
    if (n == 0) x0 else sqrtStep(c, sqrtN(c, x0, (n - 1))) // Using recursion on an inner and outer function to calculate nth power
  }


  def sqrtErr(c: Double, x0: Double, epsilon: Double): Double = {
      require(x0 >= 0) // Ensuring parameters are within range to exclude edge cases
      require(epsilon > 0) // Ensuring parameters are within range to exclude edge cases
      if (abs((x0 * x0)-c) < epsilon) x0 else sqrtErr(c, sqrtStep(c,x0), epsilon) // Utilizing the abs() and sqrStep() functions as an operation to calculate teh result
    }

  def sqrt(c: Double): Double = {
    require(c >= 0) 
    if (c == 0) 0 else sqrtErr(c, 1.0, 0.0001)
  }

  /* Search Tree */

  // Defined in Lab1Like.scala:
  //
  // sealed abstract class SearchTree
  // case object Empty extends SearchTree
  // case class Node(l: SearchTree, d: Int, r: SearchTree) extends SearchTree

  //It checks using a traversal of the tree the ordering invariant
  def repOk(t: SearchTree): Boolean = {
    def check(t: SearchTree, min: Int, max: Int): Boolean = t match {
      //Inclusive of min and exclusive of max
      case Empty => true // Ensuring parameters are within range to exclude edge cases
      case Node(l, d, r) => 
        if ((d >= min) && (d < max)) {check(l, min, d) && check(r, d, max)} else false
    } // Checking through recursion if d is a node with a value within range, and if l & r are trees with node values within range
    check(t, Int.MinValue, Int.MaxValue) // Recursivly check through the tree by testing the min and max vlaues of the nodes to ensure they follow BST rules
  }


def insert(t: SearchTree, n: Int): SearchTree = t match {
    case Empty => Node(Empty, n, Empty) // Check if the search tree is empty to insert our value into a node
    case Node(l, d, r) => { // Check where fits between the values of left and right child
      if (n < d) { 
        Node(insert(l,n), d, r) // If n < d, through recursion find an empty for insertion on the left side
      }
      else {
        Node(l,d,insert(r,n)) // If n >= d, through recursion, find an empty for insertion on the right side
      }
    }
} 


  def deleteMin(t: SearchTree): (SearchTree, Int) = {
    require(t != Empty) // Ensuring parameters are within range to exclude edge cases
    (t: @unchecked) match {  // @uncheck: it's to designate that the annotated entity should not be conssidered for additional compiler checks.
      case Node(Empty, d, r) => (r, d) // Removing the least branch
      case Node(l, d, r) =>
        val (l1, m) = deleteMin(l) // Find the node with the least value through recursion 
        (Node(l1, d, r), m) // Return the updated tree with the deleted node
    }
  }


  def delete(t: SearchTree, n: Int): SearchTree = t match {
      case Empty => Empty // If n is not exsited in SearchTree t, return Empty
      case Node(l, d, r) if(n < d)=> Node(delete(l, n), d, r) // If n < d, then through recursion check the left side of the tree
      case Node(l, d, r) if(n > d)=> Node(l, d, delete(r, n)) // If n > d, check the right side of the tree through recursion.
      case Node(l, d, Empty) => l // If the right child is empty, then return the left child
      case Node(l, d, r) =>
        val temp = deleteMin(r) // Find the node with the least value within the right child and store the min node value and updated tree
        Node(l, temp._2, temp._1) // Return the updated tree with the deleted node
  }


  /* JavaScripty */

  def eval(e: Expr): Double = e match {
    case N(n) => n // Identify if the input expression is a double, then return n
    case Unary( uop, e1 ) => uop match { 
      case Neg => -eval(e1)
      // Identify if the input expression is a negative double, convert it into a postive double, then through recursion return updated vlaue in type double
    } 
    case Binary(bop, e1, e2) => bop match{ 
      case Plus  => eval(e1) + eval(e2)  // Declaring the addition memeber function that will perform the operation through recursion on the input expression   
      case Minus => eval(e1) - eval(e2)  // Declaring the subtraction memeber function that will perform the operation through recursion on the input expression  
      case Times => eval(e1) * eval(e2)  // Declaring the multiplication memeber function that will perform the operation through recursion on the input expression  
      case Div   => eval(e1) / eval(e2)  //  Declaring the division memeber function that will perform the operation through recursion on the input expression  
    } 
    case _ => throw new UnsupportedOperationException // Ensuring input values are of acceptable type to exclude edge cases
  }


 /* Interface to run your interpreter from the command-line.  You can ignore the code below. */
 def processFile(file: java.io.File): Unit = {
    if (debug) { println("Parsing ...") }

    val expr = Parser.parseFile(file)

    if (debug) {
      println("\nExpression AST:\n  " + expr)
      println("------------------------------------------------------------")
    }

    if (debug) { println("Evaluating ...") }

    val v = eval(expr)

    println(prettyNumber(v))
  }
}