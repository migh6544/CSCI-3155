[CSCI 3155] Lab-1
Project Partners: Michael Ghattas & Jisoo Park


2. Scala Basics: Binding and Scope
a)
* pi at line 4 is bound by pi at line 3 (pi = 3.14159):
    Since pi was redeclared within the function, calling pi at line 4 will utilize the value of pi declared in the funtion at line 3.
    
* pi at line 7 is bound by pi at line 1 (pi = 3.14):
    Since pi is already delcared on line 1, and pi at line 3 can be only used in the circumference function, pi at line 7 is bound by pi at line 1.

b)
* x at line 3 is bound by x at line 2:
    x gets its value from the input value requested by f(x) on line 2, therefore, whatever the input value is x will bound to it.

* x at line 6 is bound by x at line 5:
    x that is used in val y is defined inside of case x, so  x at line 6 is according from the case x at line 5.
    
* x at line 10 is bound by x at line 5:
    The value of x on line 10 is bound by the value of x declared in the "case x" command on line 5, which evaluates the input from f(x) if (x!= 0).

* x at line 13 is bound by x at line 1:
    The variable x at line 10 is defined on the outer function of f(x:Int), so x at line 10 is bound by x at line 1.



3. Scala Basics: Typing
* Yes, the syntax is correct.
* The return type of g() is a Tuple based on the following logic:
    X: int
    (a, b): (1, (x, 3))
        val 1: Int
        val x: Int
        val 3: Int
            val a: 1
                val a: Int
            val b: (x, 3)
                val b: (Int, Int)
                    val b: Tuple

    If (x == 0) = True
        g() returns (b, 1)
             (b, 1): (Tuple, Int)
                (b, 1): Tuple

    If (x == 0) = False
        g() returns (b, a + 2)
            (b, a + 2): (Tuple, Int + Int)
                (b, a + 2): (Tuple, Int)
                    (b, a + 2): Tuple


End.