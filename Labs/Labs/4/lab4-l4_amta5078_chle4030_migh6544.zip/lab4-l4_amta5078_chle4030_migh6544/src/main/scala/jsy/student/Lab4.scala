package jsy.student

import jsy.lab4.Lab4Like

object Lab4 extends jsy.util.JsyApplication with Lab4Like {
  import jsy.lab4.ast._
  import jsy.lab4.Parser
  
  /*
   * CSCI 3155: Lab 4
   * Ami Tat
   * 
   * Partner: Chad Lenth & Micheal Ghattas
   * Collaborators: <Any Collaborators>
   */

  /*
   * Fill in the appropriate portions above by replacing things delimited
   * by '<'... '>'.
   * 
   * Replace the '???' expression with your code in each function.
   *
   * Do not make other modifications to this template, such as
   * - adding "extends App" or "extends Application" to your Lab object,
   * - adding a "main" method, and
   * - leaving any failing asserts.
   *
   * Your lab will not be graded if it does not compile.
   *
   * This template compiles without error. Before you submit comment out any
   * code that does not compile or causes a failing assert. Simply put in a
   * '???' as needed to get something that compiles without error. The '???'
   * is a Scala expression that throws the exception scala.NotImplementedError.
   */
  
  /*** Collections and Higher-Order Functions ***/
  
 /* Lists */

   def compressRec[A](l: List[A]): List[A] = l match {
     case Nil | _ :: Nil => l                                                                      // If list is empty, return empty list.
     case h1 :: (t1 @ (h2 :: _)) => if(h1 == h2) compressRec(t1) else (h1 :: compressRec(t1))      // If first two elements of the list are the same, 
   }                                                                                               // drop the first element and recurse on the tail,
                                                                                                   // else accumulate first element and recurse on the tail.
   def compressFold[A](l: List[A]): List[A] = l.foldRight(Nil: List[A]) {
     (h, acc) => acc match {                                                                       // Match on accumulated list, i.e. tail of list.
       case Nil => h :: acc                                                                        // If accumlator is null, return a list with the head followed by null.
       case h_acc :: t_acc => if(h_acc == h) acc else (h :: acc)
     }
   }

   def mapFirst[A](l: List[A])(f: A => Option[A]): List[A] = l match {
     case Nil => l                                                                                 // If list is empty, return empty list.
     case h :: t => f(h) match{                                                                    // If head is present, apply and match on function with head.
       case None => h :: mapFirst(t)(f)                                                            // If function is none, return head and recurse on tail of list with function.
       case Some(a) => a :: t                                                                      // If function is Some(a), update list with a as head and tail.
       case _ => h :: mapFirst(t)(f)                                                               // If function is else, return head and recurse on tail of list with function.
     }
   }

   /* Trees */

   def foldLeft[A](t: Tree)(z: A)(f: (A, Int) => A): A = {
     def loop(acc: A, t: Tree): A = t match {
       case Empty => acc                                                                            // If accumelator is empty, return empty accumelator.
       case Node(l, d, r) => loop(f(loop(acc,l),d),r)                                               // If accumelator is a tree,
     }                                                                                              // accumlate left subtree with leaftFold left with data,
     loop(z, t)                                                                                     // then accumulate right subtree.
   }

   /* An example use of foldLeft */
   
  def sum(t: Tree): Int = foldLeft(t)(0){ (acc, d) => acc + d }

  /* Create a tree from a list. An example use of the List.foldLeft method. */

  def treeFromList(l: List[Int]): Tree =
    l.foldLeft(Empty: Tree){ (acc, i) => acc insert i }

  def strictlyOrdered(t: Tree): Boolean = {                                                         
    val (b, _) = foldLeft(t)((true, None: Option[Int])){                                            // Use FoldLeft to return a boolean on basedon evaluated nodes.
      (acc, d) => acc match {                                                                       // Use foldLeft to return and amtch on accumulator returned.
        case (b_ac1, None) => (b_ac1, Some(d))                                                      // If the last evaluated node is None, i.e. None < d, then evaluate and return b_acc and f(d).
        case (b_ac2, nextInt) => (nextInt.get < d && b_ac2, Some(d))                                // If the last evaluated node is Some(x), check if x < d,
      }                                                                                             // if true, evaluate and return b_acc and Some(x),
    }                                                                                               // else revaluate and return false and Some(x).
    b
  }

  /*** Rename bound variables in e ***/

  def rename(e: Expr)(fresh: String => String): Expr = {
    def ren(env: Map[String,String], e: Expr): Expr = {
      e match {
        case N(_) | B(_) | Undefined | S(_) => e
        case Print(e1) => Print(ren(env, e1))

        case Unary(uop, e1) => Unary(uop, ren(env, e1))
        case Binary(bop, e1, e2) => Binary(bop, ren(env, e1), ren(env, e2))
        case If(e1, e2, e3) => If(ren(env, e1),ren(env, e2),ren(env, e3))
        case Var(y) => Var(fresh(y)) //not sure if correct
        case Decl(mode, y, e1, e2) => {
          val yp = fresh(y)
          Decl(mode,yp,ren(env,e1),ren(env,e2))
        }
        case Function(p, params, tann, e1) => {
          val (pp, envp): (Option[String], Map[String,String]) = p match {
            case None => ???
            case Some(x) => ???
          }
          val (paramsp, envpp) = params.foldRight( (Nil: List[(String,MTyp)], envp) ) {
            ???
          }
          ???
        }

        case Call(e1, args) => Call(ren(env,e1),args.map(ei => ren(env,ei)))
        case Obj(fields) => Obj(fields.map({case (fi,ei) => (fi,ren(env,ei))}))
        case GetField(e1, f) => GetField(ren(env,e1),f)
      }
    }
    ren(empty, e)
  }

  /*** Type Inference ***/

  // While this helper function is completely given, this function is
  // worth studying to see how library methods are used.
  def hasFunctionTyp(t: Typ): Boolean = t match {
    case TFunction(_, _) => true
    case TObj(fields) if (fields exists { case (_, t) => hasFunctionTyp(t) }) => true
    case _ => false
  }
  
  def typeof(env: TEnv, e: Expr): Typ = {
    def err[T](tgot: Typ, e1: Expr): T = throw StaticTypeError(tgot, e1, e)

    e match {
      case Print(e1) => typeof(env, e1); TUndefined
      case N(_) => TNumber
      case B(_) => TBool
      case Undefined => TUndefined
      case S(_) => TString
      case Var(x) => lookup(env,x)
      case Unary(Neg, e1) => typeof(env, e1) match {
        case TNumber => TNumber
        case tgot => err(tgot, e1)
      }
      case Unary(Not, e1) => typeof(env, e1) match {
        case TBool => TBool
        case tgot => err(tgot, e1)
      }
      case Binary(Plus, e1, e2) => (typeof(env, e1), typeof(env, e2)) match {
        case (TString,TString) => TString
        case (TNumber,TNumber) => TNumber
        case (tgot,_) if (tgot != TNumber && tgot != TString) => err(tgot, e1)
        case (_,tgot) => err(tgot, e2)
      }
      case Binary(Minus|Times|Div, e1, e2) => (typeof(env, e1), typeof(env, e2)) match {
        case (TNumber,TNumber) => TNumber
        case (tgot, _) if (tgot != TNumber) => err(tgot, e1)
        case (_, tgot) => err(tgot, e2) 
      }
      case Binary(Eq|Ne, e1, e2) => {
        (typeof(env, e1), typeof(env, e2)) match {
          case (tgot, _) if (hasFunctionTyp(tgot)) => err(tgot, e1)
          case (_, tgot) if (hasFunctionTyp(tgot)) => err(tgot, e2)
          case (_, _) => if (typeof(env, e1) == typeof(env, e2)) TBool else err(typeof(env, e2), e2) 
        }
      }
      case Binary(Lt|Le|Gt|Ge, e1, e2) => (typeof(env, e1), typeof(env, e2)) match {
        case (TString, TString) => TBool
        case (TNumber, TNumber) => TBool
        case (tgot, _) if (tgot != TNumber && tgot != TString) => err(tgot, e1)
        case (_, tgot) => err(tgot, e2) 
      }
      case Binary(And|Or, e1, e2) => (typeof(env, e1), typeof(env, e2)) match {
        case (TBool, TBool) => TBool
        case (tgot, _) if (tgot != TBool) => err(tgot, e1)
        case (_, tgot) => err(tgot, e2) 
      }
      case Binary(Seq, e1, e2) => typeof(env, e1); typeof(env, e2)
      case If(e1, e2, e3) => typeof(env, e1) match { 
        case (TBool) => if (typeof(env, e2) == typeof(env, e3)) typeof(env, e2) else err(typeof(env, e3), e3)
        case (tgot) => err(tgot, e1)  
      }
      case Decl(m, x, e1, e2) => typeof(env + (x -> typeof(env, e1)), e2)
      case Obj(fields) => TObj(fields.map {case (k, v) => (k, typeof(env, v))})
      case GetField(e1, f) => {
        val t = typeof(env, e1)
        t match {
          case TObj(fields) => fields.get(f) match {
            case None => err(t, e1)
            case Some(v) => v
          }
        case _ => err(t, e1)
        }
      }
      case Function(p, params, tann, e1) => {
        // Bind to env1 an environment that extends env with an appropriate binding if
        // the function is potentially recursive.
        val env1 = (p, tann) match {
          /***** Add cases here *****/
          //type rec function case
          case (Some(x), Some(t)) => 
            val tp = TFunction(params, t)
            env + (x -> tp)
            //extend(env, x, tp)
          //case for type function and ann
          case (None, _ ) => env
          case _ => err(TUndefined, e1)
        }
        // Bind to env2 an environment that extends env1 with bindings for params.
        val env2 = params.foldLeft(env1) {
          case (envacc, parami) => val (xi, MTyp(_, ti)) = parami 
          envacc + (xi -> ti)
          //extend(envacc, xi, ti)
        }
        // Infer the type of the function body
        val t1 = typeof(env2, e1)
        val tret = TFunction(params, t1)
        // Check with the possibly annotated return type
        tann match {
          case Some(t) if (t1 == t) => tret 
          case Some(_) => err(t1, e1)
          case None => tret
        }
      }
      case Call(e1, args) => typeof(env, e1) match {
        case TFunction(params, tret) if (params.length == args.length) => {
          (params zip args).foreach { zippedarg => 
            val (parami, ei) = zippedarg
            val(_, MTyp(_, ti)) = parami
            if (ti != typeof(env, ei)) err(typeof(env, ei), ei) else typeof(env, ei)
          }
          tret
        }
        case tgot => err(tgot, e1)
      }
    }
  }
  
  /*** Small-Step Interpreter ***/

  /*
   * Helper function that implements the semantics of inequality
   * operators Lt, Le, Gt, and Ge on values.
   *
   * We suggest a refactoring of code from Lab 2 to be able to
   * use this helper function in eval and step.
   *
   * This should the same code as from Lab 3.
   */
  def inequalityVal(bop: Bop, v1: Expr, v2: Expr): Boolean = {
    require(bop == Lt || bop == Le || bop == Gt || bop == Ge)
    ((v1, v2): @unchecked) match {
      case (S(s1), S(s2)) => (bop: @unchecked) match { //DoInequalityString
        case Lt => if(s1 < s2) true else false
        case Le => if(s1 <= s2) true else false
        case Gt => if(s1 > s2) true else false
        case Ge => if(s1 >= s2) true else false
      }
      case (N(n1), N(n2)) => (bop: @unchecked) match { //DoInequalityNumber
        case Lt => if(n1 < n2) true else false
        case Le => if(n1 <= n2) true else false
        case Gt => if(n1 > n2) true else false
        case Ge => if(n1 >= n2) true else false
      }
      case _ => throw StuckError(Binary(bop, v1, v2))
    }
  }

  /* This should be the same code as from Lab 3 */
  def iterate(e0: Expr)(next: (Expr, Int) => Option[Expr]): Expr = {
    def loop(e: Expr, n: Int): Expr = next(e, n) match {
      case None => e
      case Some(ep) => loop(ep, n + 1)                                                                 //keep looping while incrementing counter
    }
    loop(e0, 0)
  }

  /* Capture-avoiding substitution in e replacing variables x with esub. */
  def substitute(e: Expr, esub: Expr, x: String): Expr = {
    require(isValue(esub))
    def subst(e: Expr): Expr = e match {
      case N(_) | B(_) | Undefined | S(_) => e
      case Print(e1) => Print(subst(e1))
        /***** Cases from Lab 3 */
      case Unary(uop, e1) => Unary(uop, subst(e1))
      case Binary(bop, e1, e2) => Binary(bop, subst(e1), subst(e2))
      case If(e1, e2, e3) => If(subst(e1),subst(e2),subst(e3))
      case Var(y) => if(x == y) esub else e
      case Decl(mode, y, e1, e2) => if(x == y) Decl(mode, y, subst(e1), e2) else Decl(mode, y, subst(e1),subst(e2)) 
        /***** Cases needing adapting from Lab 3 */
      case Function(p, params, tann, e1) => p match {
        case None => if (params.exists((t1: (String, MTyp)) => t1._1 == x)) Function(p, params, tann, e1) else Function(p, params, tann, subst(e1))
        case Some(y) => if(params.exists((t1: (String, MTyp)) => t1._1 == x) || y == x) Function(Some(y), params, tann, e1) else Function(Some(y), params, tann, subst(e1))
      }
      case Call(e1, args) =>  Call(subst(e1), args map subst) //loops through the list in arg we think it works
        /***** New cases for Lab 4 */
      case Obj(fields) => Obj(fields.map({case (si, ei) => (si, subst(ei))})) 
      case GetField(e1, f) => if (x != f) GetField(subst(e1), f) else e
    }
    //renaming bound variables of the same name as the free variables
    val fvs = freeVars(esub)
    def fresh(x: String): String = if (fvs.contains(x)) fresh(x + "$") else x
    subst(e)                                                                                        // change this line if/when you implement capture-avoidance for call-by-name
  }

  /* Helper function for implementing call-by-name: check whether or not an expression is reduced enough to be applied given a mode. */
  def isRedex(mode: Mode, e: Expr): Boolean = mode match {
    case MConst => !isValue(e)
    case MName => false
  }

  /* A small-step transition. */
  def step(e: Expr): Expr = {
    require(!isValue(e), s"step: e ${e} to step is a value")
    e match {
      /* Base Cases: Do Rules */
      case Print(v1) if isValue(v1) => println(pretty(v1)); Undefined //DoPrint
        /***** Cases needing adapting from Lab 3. */
      case Unary(Neg, v1) if isValue(v1) => v1 match { //DoNeg
        case N(n1) => N(-n1)
        case _ => throw StuckError(e)
      }
      case Unary(Not, v1) if isValue(v1) => v1 match { //DoNot
        case B(b1) => B(!b1)
        case _ => throw StuckError(e)
      }
      case Binary(bop, v1, v2) if(isValue(v1) && isValue(v2)) => (bop: @unchecked) match {
        case Plus => (v1, v2) match { 
          case (S(s1), S(s2)) => S(s1 + s2) //DoPlusString
          case (N(n1), N(n2)) => N(n1 + n2) //DoArith
          case _ => throw StuckError(e)
        }
        case Minus => (v1, v2) match { //DoArith
          case (N(n1), N(n2)) => N(n1 - n2)
          case _ => throw StuckError(e)
        }
        case Times =>(v1, v2) match { //DoArith
          case (N(n1), N(n2)) => N(n1 * n2)
          case _ => throw StuckError(e)
        }
        case Div => (v1, v2) match {
          case (N(n1), N(n2)) => N(n1 / n2)
          case _ => throw StuckError(e)
        }
        case (Lt | Le | Gt | Ge) => B(inequalityVal(bop, v1, v2)) //DoInequality
        case Eq => B(v1 == v2) //DoEquality
        case Ne => B(v1 != v2) //DoEquality
        //repeat Seq, And, Or in case both expressions are values
        case Seq => v2 //DoSeq
        case And => v1 match {
          case B(true) => v2 //DoAndTrue
          case B(false) => B(false) //DoAndFalse
          case _ => throw StuckError(e)
        }
        case Or => v1 match{
          case B(true) => B(true) //DoOrTrue
          case B(false) => v2 //DoOrFalse
          case _ => throw StuckError(e)
        }
        case _ => throw StuckError(e)
      }
      case Binary(bop, v1, e2) if(isValue(v1)) => bop match { 
        case Seq => e2 //DoSeq
        case And => v1 match {
          case B(true) => e2 //DoAndTrue
          case B(false) => B(false) //DoAndFalse
          case _ => throw StuckError(e)
        }
        case Or => v1 match{
          case B(true) => B(true) //DoOrTrue
          case B(false) => e2 //DoOrFalse
          case _ => throw StuckError(e)
        }
        case _ => Binary(bop, v1, step(e2)) //SearchBinary2
      }
      case Binary(bop, e1, e2) => Binary(bop, step(e1), e2) //SearchBinary1   
      case If(v1, e2, e3) if(isValue(v1)) => v1 match { 
        case B(true) => e2 //DoIfTrue
        case B(false) => e3 //DoIfFalse
        case _ => throw StuckError(e)
      }                                     //SearchBinary1 moved below SearchBinary2 to reach SearchBinary2
      case Decl(const, x, v1, e2) if(isValue(v1)) => substitute(e2, v1, x) //DoDecl
        /***** More cases here */
      case Call(v1, args) if (isValue(v1)) =>
        v1 match {
          case Function(p, params, _, e1) => {
            val pazip = params zip args                                                             //((xn, Mtyp), en)
            if (pazip.forall({case((xni, MTyp(mi, ti)), eni) => !isRedex(mi, eni)})) { //DoCall & DoCallREc              //args forall isValue 
              val e1p = pazip.foldRight(e1) {
                case ((xn, mtyp), en) => substitute(en, mtyp, xn._1)                                // This returns a derefrebced pointer to epi
              }
              p match {
                case None => e1p
                case Some(x1) => substitute(e1p, v1, x1)
              }
            }
            else { //SearchCall2                                                                               
              val pazipp = mapFirst(pazip) {                                                        //finding the first index in which isRedex is true
                case((xni, MTyp(mi, ti)), eni) if isRedex(mi, eni) => Some(((xni, MTyp(mi, ti)), step(eni)))
                case _ => None
             }
              Call(v1, pazipp.unzip._2)                                                             // found the method unzip to access only arguments
            }
          }
          case _ => throw StuckError(e)
        }
        /***** New cases for Lab 4. */
      case GetField(v1, f) if(isValue(v1)) => v1 match { //DoGetField                                         //v1 is a list of fields according to the inference rule
        case Obj(fields) => fields.get(f) match {                                                 //finding element matching fi
          case Some(vi) => vi                                                                       //if element contains something aka vi, return vi
          case None => throw StuckError(e)
        }
        case _ => throw StuckError(e)
      }
      /* Inductive Cases: Search Rules */
      case Print(e1) => Print(step(e1)) //SearchPrint
        /***** Cases from Lab 3. */
      case Unary(uop, e1) => Unary(uop, step(e1)) //SearchUnary
      //moved search binary cases up for easier troubleshooting
      case If(e1, e2, e3) => If(step(e1), e2, e3) //SearchIf
      case Decl(const, x, e1, e2) => Decl(const, x, step(e1), e2) //SearchDecl
        /***** More cases here */
        /***** Cases needing adapting from Lab 3 */
      case Call(e1, args) => Call(step(e1), args) //SearchCall1
        /***** New cases for Lab 4. */
      case GetField(e1, f) if(!isValue(e1)) => e1 match { //SearchGetField
        case Obj(_) => GetField(step(e1), f)                                                         // step object
        case _ => throw StuckError(e)
      }
      case Obj(fields) if(!isValue(e))=> { //SearchObject
        fields.find(f=> !isValue(f._2)) match {
          case Some((si, ei)) => Obj(fields.map({case (si, ei) => (si, step(ei))}))
          case None => throw StuckError(e)
        }
      }
      /* Everything else is a stuck error. Should not happen if e is well-typed.
       *
       * Tip: you might want to first develop by comment out the following line to see which
       * cases you have missing. You then uncomment this line when you are sure all the cases
       * that you have left are ones that should be stuck.
       */
      case _ => throw StuckError(e)
    }
  }
  
  
  /* External Interfaces */
  
  //this.debug = true // uncomment this if you want to print debugging information
  this.maxSteps = Some(1000) // comment this out or set to None to not bound the number of steps.
  this.keepGoing = true // comment this out if you want to stop at first exception when processing a file
}
