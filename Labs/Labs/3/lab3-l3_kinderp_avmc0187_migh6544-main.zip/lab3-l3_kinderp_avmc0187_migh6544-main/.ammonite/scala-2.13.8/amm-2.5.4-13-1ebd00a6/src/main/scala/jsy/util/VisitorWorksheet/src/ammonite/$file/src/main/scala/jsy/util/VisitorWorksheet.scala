
package ammonite
package $file.src.main.scala.jsy.util
import _root_.ammonite.interp.api.InterpBridge.{
  value => interp
}
import _root_.ammonite.interp.api.InterpBridge.value.{
  exit,
  scalaVersion
}
import _root_.ammonite.interp.api.IvyConstructor.{
  ArtifactIdExt,
  GroupIdExt
}
import _root_.ammonite.compiler.CompilerExtensions.{
  CompilerInterpAPIExtensions,
  CompilerReplAPIExtensions
}
import _root_.ammonite.runtime.tools.{
  browse,
  grep,
  time,
  tail
}
import _root_.ammonite.compiler.tools.{
  desugar,
  source
}
import _root_.mainargs.{
  arg,
  main
}
import _root_.ammonite.repl.tools.Util.{
  PathRead
}


object VisitorWorksheet{
/*<script>*/import jsy.lab5.ast._
import jsy.lab5.Parser.parse

import jsy.util.Visitor

val oldheight: Visitor[Expr,Int] = Visitor(rec => {
  case N(_) => 1
  case Binary(_, e1, e2) => 1 + (rec(e1) max rec(e2))
})


val olde: Expr = parse("1 + (1 + 2)")
val oldh = oldheight(olde)


case class Foo(e: Expr) extends Expr
val newe: Expr = Binary(Plus, Foo(olde), N(3))

val newheight: Visitor[Expr,Int] = oldheight extendWith ((rec: Expr => Int) => {
  case Foo(e1) => 1 + rec(e1)
})

val newh = newheight(newe)

/*</script>*/ /*<generated>*/
def $main() = { scala.Iterator[String]() }
  override def toString = "VisitorWorksheet"
  /*</generated>*/
}
