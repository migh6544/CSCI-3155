/*
 * CSCI 3155: Lab 2 JavaScript Worksheet
 *
 * This worksheet is a place to experiment with JavaScript expressions.
 */

const five = 5;

five + "five";

console.log(five), console.log("five");

undefined - true;

10 * false;

10 * undefined;

console.log(undefined ? "then" : "else");

console.log("" ? "then" : "else");