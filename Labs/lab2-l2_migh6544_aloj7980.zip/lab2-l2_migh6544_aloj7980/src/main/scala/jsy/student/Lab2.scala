package jsy.student

import jsy.lab2.Lab2Like

object Lab2 extends jsy.util.JsyApplication with Lab2Like {
  import jsy.lab2.Parser
  import jsy.lab2.ast._

  /*
   * CSCI 3155: Lab 2
   * Michael Ghattas
   * 
   * Partner: Alex Ojemann
   * Collaborators: <None>
   */

  /*
   * Fill in the appropriate portions above by replacing things delimited
   * by '<'... '>'.
   * 
   * Replace the '???' expression with  your code in each function.
   * 
   * Do not make other modifications to this template, such as
   * - adding "extends App" or "extends Application" to your Lab object,
   * - adding a "main" method, and
   * - leaving any failing asserts.
   * 
   * Your lab will not be graded if it does not compile.
   * 
   * This template compiles without error. Before you submit comment out any
   * code that does not compile or causes a failing assert. Simply put in a
   * '???' as needed to get something  that compiles without error. The '???'
   * is a Scala expression that throws the exception scala.NotImplementedError.
   *
   */

  /* We represent a variable environment as a map from a string of the
   * variable name to the value to which it is bound.
   * 
   * You may use the following provided helper functions to manipulate
   * environments, which are just thin wrappers around the Map type
   * in the Scala standard library.  You can use the Scala standard
   * library directly, but these are the only interfaces that you
   * need.
   */

  /* Some useful Scala methods for working with Scala values include:
   * - Double.NaN
   * - s.toDouble (for s: String)
   * - n.isNaN (for n: Double)
   * - n.isWhole (for n: Double)
   * - s (for n: Double)
   * - s format n (for s: String [a format string like for printf], n: Double)
   *
   * You can catch an exception in Scala using:
   * try ... catch { case ... => ... }
   */

  /* Take in an expression and converts it to a double */
  def toNumber(v: Expr): Double = {                                                                      // Declaring function toNumber() and its parameters
    require(isValue(v))                                                                                  // Ensuring the input is a value and not an expression
    (v: @unchecked) match {                                                                              // Declaring a matching case for the input value
      case N(n) => n                                                                                     // If v is of case N() = double, then return v
      case B(b) => if (b == true) 1 else 0                                                              // If v is a boolean, then return 1 for true and 0 for false
      case S(s) => try s.toDouble catch {case _: Throwable => Double.NaN}                                                                           // If v is a string, convert the string into a double
      case Undefined => Double.NaN 
      case _ => throw new UnsupportedOperationException
    }                                                                                                    // End matching declaration scope
  }                                                                                                      // End function toNumber() declaration scope

  /* Take in an expression and converts it to a boolean */
  def toBoolean(v: Expr): Boolean = {                                                                    // Declaring function toBoolean() and its parameters
    require(isValue(v))                                                                                  // Ensuring the input is a value and not an expression
    (v: @unchecked) match {  
      case N(n) => if(n == 0.0 || n == -0.0 || n.isNaN) false else true                                                                                // If v is of case N() = double, then if v != 0 or NaN return false, else returrn true
      case B(b) => b
      case S(s) => if(s=="") false else true                                                                                  // Check the numeric value of the converted string through recursion                                               
      case Undefined => false
      case _ => throw new UnsupportedOperationException
    }                                                                                                    // End matching declaration scope
  }                                                                                                      // End function toNumber() declaration scope
  
  /* Take in an expression and converts it to a string */
  def toStr(v: Expr): String = {                                                                         // Declaring function toStr() and its parameters
    require(isValue(v))                                                                                  // Ensuring the input is a value and not an expression
    (v: @unchecked) match {                                                                              // Declaring a matching case for the input value
      case N(n) => if(n.isWhole) "%.0f" format n else n.toString                                                                           // If v is of case N() = double, then convert v to string and return value
      case B(b) => if (b == true) "true" else "false"                                                    // If v is a boolean, then return true for v == true else return false
      case S(s) => s                                                                                     // If v is a string, return v
      case Undefined => "undefined"
      case _ => throw new UnsupportedOperationException
    }                                                                                                    // End matching declaration scope
  }                                                                                                      // End function toNumber() declaration scope

 /* Take in an environment and an expression and evaluates an axpression in the environment and returns a simplified expression */ 
  def eval(env: Env, e: Expr): Expr = {                                                                  // Declaring function eval() and its parameters 
    e match {                                                                                  // Declaring a matching case for the input value
      /* Base Cases */
      case N(n) => N(n)                                                                                  // If e is a double return N(e)
      case B(b) => B(b)                                                                                  // If e is a boolean return B(e)
      case S(s) => S(s)
      case Var(x) => eval(env, lookup(env, x))                                                           // If e is a string return S(e)
      case Undefined => Undefined                                                                        // If e is a undefined return undefined
      /* Inductive Cases */
      case Unary(uop, e1) => uop match {                                                                 // Declaring Unary operations function, its parameters, and matching cases
        case Neg => N(-(toNumber(eval(env,e1))))                                                                   // If e1 is a negative double expression return -N(e1) through toNumber() 
        case Not => B(!(toBoolean(eval(env,e1))))                                                                 // If e1 is a boolean negation return !(e1) through toBoolean()
      }
      case Binary(bop, e1, e2) => bop match {                                                            // Declaring Binbary operations function, its parameters, and matching cases   
        case Plus => {
            val x = eval(env,e1)
            val y = eval(env,e2)
            x match{
              case S(s) => S(toStr(eval(env, e1)) + toStr(eval(env, e2)))
              case _ => y match{
                case S(s) => S(toStr(eval(env, e1)) + toStr(eval(env, e2)))
                case _ => N(toNumber(eval(env, e1)) + toNumber(eval(env, e2))) 
              }
            }
        }
        case Minus => N(toNumber(eval(env, e1)) - toNumber(eval(env, e2)))     // In case of addition, evaluate each expresion, convert them to a numbers through toNumber() individually, then add the numbers
        case Times => N(toNumber(eval(env, e1)) * toNumber(eval(env, e2)))
        case Div => N(toNumber(eval(env, e1)) / toNumber(eval(env, e2)))
        case Eq => B(eval(env, e1) == eval(env, e2))
        case Ne => B(eval(env, e1) != eval(env, e2))
        case Lt => {
            val x = (eval(env,e1),eval(env,e2))
            x match {
            case (S(s1), S(s2)) => B(toStr(eval(env,e1)) < toStr(eval(env,e2)))
            case _ => B(toNumber(eval(env,e1)) < toNumber(eval(env,e2)))
            }
          }
          case Le => {
            val x = (eval(env,e1),eval(env,e2))
            x match {
            case (S(s1), S(s2)) => B(toStr(eval(env,e1)) <= toStr(eval(env,e2)))
            case _ => B(toNumber(eval(env,e1)) <= toNumber(eval(env,e2)))
            }
          }
          case Gt => {
            val x = (eval(env,e1),eval(env,e2))
            x match {
            case (S(s1), S(s2)) => B(toStr(eval(env,e1)) > toStr(eval(env,e2)))
            case _ => B(toNumber(eval(env,e1)) > toNumber(eval(env,e2)))
            }
          }
          case Ge => {
            val x = (eval(env,e1),eval(env,e2))
            x match {
            case (S(s1), S(s2)) => B(toStr(eval(env,e1)) >= toStr(eval(env,e2)))
            case _ => B(toNumber(eval(env,e1)) >= toNumber(eval(env,e2)))
            }
          }
        case And => if(toBoolean(eval(env,e1))) eval(env,e2) else eval(env,e1)
        case Or => if(toBoolean(eval(env,e1))) eval(env,e1) else eval(env,e2)
        case Seq => {
          val x = eval(env,e1)
          val y = eval(env,e2)
          y
        }
        case _ => ???                                                                                  // TBC
      }
      case If(e1, e2, e3) => if (toBoolean(eval(env,e1))) eval(env,e2) else eval(env,e3)
      case Print(e1) => println(pretty(eval(env, e1))); Undefined                                        // Print output for undefined expressions 
      case ConstDecl (x, e1, e2) => {
        val v1 = eval(env, e1)
        val env2 = extend(env, x , eval(env, v1))
        eval(env2, e2)
      }  
      case _ => ???                                                                                      // TBC
    }
  }



  /* Interface to run your interpreter from the command-line.  You can ignore what's below. */
  def processFile(file: java.io.File): Unit =  {
    if (debug) { println("Parsing ...") }

    val expr = Parser.parseFile(file)

    if (debug) {
      println("\nExpression AST:\n  " + expr)
      println("------------------------------------------------------------")
    }

    if (debug) { println("Evaluating ...") }

    val v = eval(expr)

     println(pretty(v))
  }
}
