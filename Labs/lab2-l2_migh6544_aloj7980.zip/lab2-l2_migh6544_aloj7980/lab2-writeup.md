# Names: (Michael Ghattas | Alex Ojemann)

## Question-2

### a)

    A: Can have one or more (a)s

    B: Can have any number of combinations made from (b) and (c) where the total number of (b)s is equal to the total number of (c)s and the total number of (c)s in any substring starting from the beginning can't be more that the total number of (b)s in that substring.

    S: Can have one or more (a)s followed by any number of combinations made from (b) and (c) where the total number of (b)s is equal to the total number of (c)s, and the total number of (c)s in any substring starting from the beginning can't be more that the total number of (b)s in that substring followed by one or more (a)s.

### b)

    1. S -> AaBb -> baBb -> baab
    2. Not described by grammar (Violation: Must have min. 2 (a)s in middle)
    3. Not described by grammar (Violation: Must end with atleast one (b))
    4. S -> AaBb -> AbaBb -> Abaab -> bbaab

### c)

    [2c.jpeg](https://github.com/csci3155-f22/lab2-l2_migh6544_aloj7980/blob/main/2c.jpeg)

### d)

    [2d.png](https://github.com/csci3155-f22/lab2-l2_migh6544_aloj7980/blob/main/2d.png)

### e)

    [2e.jpg](https://github.com/csci3155-f22/lab2-l2_migh6544_aloj7980/blob/main/2e.jpg)

## Question-3

### a)

    i. The first grammar generates expressions with one or more operands and zero or more operators such that an operator is always followed by an operand and an operand is always followed by an operator. The second grammar generates expressions with one or more operands and zero or more operators such that an operator is always followed by an operand and an operand is always followed by an operator. 

    ii. These grammars produce the same expressions because in the first one e has a base case of operand and a recursive case of “e operator operand” which allows you to repeat the sequence “operator operand” infinitely and in the second grammar e only has one case, operand esuffix, but esuffix has a base case of epsilon, the empty siting, so the base case is effectively operand, and esuffix has a recursive case of “operator operand esuffix” which also allows the sequence “operator operand” to be repeated infinitely.

### b)

    Let "<<" = "*"
    3 - 5 * 2 => -7
    -> 3 - (5 * 2) => -7
    -> (3 - 5) * 2 => -4
    Thus: We know that multiplication and division take precedence over addition and subtraction due to the order of operations of arethmetics

### c)

    NonZeroStartNumber ::= NonZeroDigit | NonZeroDigit Number
    SignOption ::= - | $\epsilon$
    Number ::= Digit | Digit Number
    Digit ::= 0 | NonZeroDigit
    NonZeroDigit ::= 1 | 2 | 3 | 4 | 5 | ... | 9

# End.
